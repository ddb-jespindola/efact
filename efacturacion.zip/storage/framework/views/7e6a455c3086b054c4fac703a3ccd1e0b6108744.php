<div class="container mt-5">
    <div class="row text-center d-flex justify-content-center">
        <div class="col-md-6 ">
            <div>
                <h1 class="">Confirmación de recibido</h1>
                <div class="card bg-success text-light">
                    <div class="card-body">
                        La factura se ha marcado como Aceptada
                    </div>
                </div>
                <div class="card mt-2">
                    <div class="card-body">
                        <p>Si desea mas informacion, comuniquese con nosotros:</p>
                        <p>Tel:</p>
                        <p>Mail:</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\efacturacion\resources\views/components/confirmado.blade.php ENDPATH**/ ?>