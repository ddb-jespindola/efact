 <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<div id="ddbcontent" class="container mt-5">
    <div class="row d-flex justify-content-center">
        <div class="col-md-8">
            <div class="row  d-flex justify-content-center">
                <div class="card mt-2 p-2">
                    <div class="row">
                        <p class="text-center"><strong>Documento registrado, este documento ya se encuentra registrado en nuestra Base de Datos</strong></p>
                    </div>    
                </div>
                
                <div class="card mt-4">
                    <div class="card-body text-right">
                        <!-- Cliente -->
                        <div class="row d-flex justify-content-start">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-4 text-center">
                                        <span><strong>Cliente:</strong></span>
                                    </div>
                                    <div class="col-md-8 text-left">
                                        <span class="text-left">CLINICA NUEVA DE BOGOTA</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-4  text-center">
                                        <label for=""><strong>Identificación:</strong></label>
                                    </div>
                                    <div class="col-md-8">
                                        <label for="">4229</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Factura - Fecha -->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-4 text-center">
                                        <label for=""><strong>Factura:</strong></label>
                                    </div>
                                    <div class="col-md-8">
                                        <label for=""><?php echo e($data->dat3); ?> <?php echo e($data->dat4); ?></label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-4 text-center">
                                        <label for=""><strong>Fecha:</strong></label>
                                    </div>
                                    <div class="col-md-8">
                                        <label for="">19/02/2021</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($data->STATUS == '3'): ?>
                         <?php if (isset($component)) { $__componentOriginala16fe35342f1ca3e7ebe928eaea7584dc5f1d160 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Mensajeaceptado::class, []); ?>
<?php $component->withName('mensajeaceptado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginala16fe35342f1ca3e7ebe928eaea7584dc5f1d160)): ?>
<?php $component = $__componentOriginala16fe35342f1ca3e7ebe928eaea7584dc5f1d160; ?>
<?php unset($__componentOriginala16fe35342f1ca3e7ebe928eaea7584dc5f1d160); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php elseif($data->STATUS == '4'): ?>
                         <?php if (isset($component)) { $__componentOriginalab5c85b13e8ea925fcccae866411c9f3e318b50f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Mensajerechazado::class, []); ?>
<?php $component->withName('mensajerechazado'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalab5c85b13e8ea925fcccae866411c9f3e318b50f)): ?>
<?php $component = $__componentOriginalab5c85b13e8ea925fcccae866411c9f3e318b50f; ?>
<?php unset($__componentOriginalab5c85b13e8ea925fcccae866411c9f3e318b50f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php endif; ?>

                </div>

                <div class="card mt-2">
                    <div class="card-body">
                        <p class="">De acuerdo a los términos del decreto 1154 del 20 de Agosto de 2020, si usted es obligado o voluntario para recibir Documentos electrónicamente, debe realizar la confirmación o rechazo de los mismos, de lo contrarío luego de tres días hábiles, se entenderán como aceptados tácitamente y podrá iniciarse un proceso de factoring electrónico.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\laragon\www\efacturacion\resources\views/accepted.blade.php ENDPATH**/ ?>