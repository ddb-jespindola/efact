 <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<div class="bg-gray container mt-5">
    <table class="table table-bordered border-primary">
        <thead>
        <tr>
            <th scope="col">Cliente</th>
            <th scope="col">Ejercicio</th>
            <th scope="col">Serie</th>
            <th scope="col">Factura</th>
            <th scope="col">Estado factura</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($factura->CLIENTE); ?></th>
                    <td><?php echo e($factura->EJERCICIO); ?></td>
                    <td><?php echo e($factura->SERIE); ?></td>
                    <td><?php echo e($factura->FACTURA); ?></td>
                    
                        <?php if($factura->STATUS == '0'): ?>  
                        <td class="">Sin acusar</td>
                        <?php endif; ?>
                        <?php if($factura->STATUS == '1'): ?>  
                        <td class="">Acusado</td>
                        <?php endif; ?>
                        <?php if($factura->STATUS == '2'): ?>  
                        <td class="text-success">Aceptada tacitamente</td>
                        <?php endif; ?>
                        <?php if($factura->STATUS == '3'): ?>  
                        <td class="text-success">Aceptada</td>
                        <?php endif; ?>
                        <?php if($factura->STATUS == '4'): ?>  
                        <td class="text-danger">Rechazada</td>
                        <?php endif; ?>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </tbody>

    </table>
  </div><?php /**PATH C:\laragon\www\efacturacion\resources\views/registros.blade.php ENDPATH**/ ?>