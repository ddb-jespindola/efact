<div class="container mt-5">
    <div class="row text-center d-flex justify-content-center">
        <div class="col-md-6 ">
            <div>
                <h1 class="">Atención</h1>
                <div class="card bg-danger text-light">
                    <div class="card-body">
                        <strong>Esta factura ya habia sido registrada</strong>
                    </div>
                </div>
                <div class="card mt-2">
                    <div class="card-body">
                        <p>Si desea mas informacion, comuniquese con nosotros:</p>
                        <p>Tel:</p>
                        <p>Mail:</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\efacturacion\resources\views/components/existente.blade.php ENDPATH**/ ?>