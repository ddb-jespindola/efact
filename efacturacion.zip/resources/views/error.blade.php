<x-header/>
    <div class="container mt-5">
        <div class="row d-flex justify-content-center">
            <div class="col-md-6">
                <div class="card border border-danger">
                    <h2 class="text-center">Ha ocurrido un error</h2>
                </div>
                <div class="card border border-danger mt-3 p-4">
                    <h4 class="text-center">Comunícate con nosotros</h4>
                    <div class="row mt-3 text-center">
                        <div class="col-md-12 d-block px-5">
                            <div>
                                <strong>Telefono: </strong>
                                <a href="tel:(1)7432597">(1) 743 25 97</a>
                            </div>
                            <div>
                                <strong>Movil: </strong>
                                <a href="tel:(+57)3007484272">(+57) 300 748 42 72</a>
                            </div>
                            <div>
                                <strong>Mail: </strong>
                                <a href="mailto:info@ddb.com.co">info@ddb.com.co</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<x-footer/>