<div class="card bg-success text-light mt-2 p-2">
    <div class="row">
        <p class="text-center"><strong>Documento Aceptado</strong></p>
    </div>    
</div>