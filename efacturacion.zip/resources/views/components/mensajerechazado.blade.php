<div class="card bg-danger text-light mt-2 p-2">
    <div class="row">
        <p class="text-center"><strong>Documento Rechazado</strong></p>
    </div>    
</div>