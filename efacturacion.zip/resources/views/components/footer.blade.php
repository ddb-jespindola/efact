</section>
<footer class="bg-dark text-light mt-5 d-flex justify-content-center align-items-center" style="min-height: 100px;">
    <div class="container">
        <div class="row text-center ">
            <div class="d-block">
                <a class ="text-decoration-none text-light" href="https://ddb.com.co" target="_blank" rel="noopener noreferrer">ddb.com.do</a>
            </div>
        </div>
    </div>
</footer>
</body>